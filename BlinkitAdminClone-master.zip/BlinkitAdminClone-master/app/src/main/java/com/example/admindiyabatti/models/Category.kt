package com.example.admindiyabatti.models

data class Category(
    var category: String ,
    var icon: Int
)
