package com.example.admindiyabatti.models

data class Notification(
    val to: String? = null,
    val data: NotificationData
)
