package com.example.admindiyabatti.models

data class Admin(

    var uid: String? = null,
    val userPhoneNumber: String? = null,
    var adminToken: String? = null,
)
