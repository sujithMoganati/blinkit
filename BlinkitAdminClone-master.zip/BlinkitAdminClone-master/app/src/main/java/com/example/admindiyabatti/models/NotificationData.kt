package com.example.admindiyabatti.models

data class NotificationData(
    val title: String? = null,
    val body: String? = null,

    )
